
class Dato1 {
    static {
        System.out.println("carica Dato1");
    }
    public static void saluta() {System.out.println("CIAO");}
}

class Dato2 {
    static {
        System.out.println("carica Dato2");
    }
}

public class Esempio1 {
    public static void main(String[] args) {
        System.out.println("inizia main");
        Dato1.saluta();
        Dato1 d1 = new Dato1();
        try {
            Class c = Class.forName("Dato2");
        } catch (ClassNotFoundException e) {System.out.println("Errore: " + e.getMessage());}
        try {
            Class c = Class.forName("Dato10");
        } catch (ClassNotFoundException e) {System.out.println("Errore: " + e.getMessage());}
    }
}
