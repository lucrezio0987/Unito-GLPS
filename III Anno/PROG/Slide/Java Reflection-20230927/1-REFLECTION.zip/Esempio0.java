
import java.util.ArrayList;

public class Esempio0 {

    public static void main(String[] args) {
        String f = "Ciao";
        Class c = f.getClass();
        System.out.println("Ciao e' istanza di " + c.getName() +
        					"? " + c.isInstance(f));
        ArrayList ar = new ArrayList();
        System.out.println("L'ArrayList e' istanza di " +
        					c.getName() + "? " + c.isInstance(ar));
        System.out.println("La classe e' " + ar.getClass().getName());
    }
}
