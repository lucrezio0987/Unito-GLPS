package catering.businesslogic.recipe;

import catering.businesslogic.KitchenJobManagement.*;

import java.util.ArrayList;

public class Preparazione extends Mansione {
    public Preparazione(String nome, String descrizione, double tempo, double quantita) {
        super(nome, descrizione, tempo, quantita);
    }

}
