package catering.businesslogic.ShiftManagement;

public class StaffMember {
    String name;

    public StaffMember(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
