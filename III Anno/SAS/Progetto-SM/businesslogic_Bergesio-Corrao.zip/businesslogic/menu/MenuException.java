package catering.businesslogic.menu;

public class MenuException extends Exception {
}
