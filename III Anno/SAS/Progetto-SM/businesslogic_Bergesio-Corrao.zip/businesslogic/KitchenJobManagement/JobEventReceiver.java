package catering.businesslogic.KitchenJobManagement;

import catering.businesslogic.ShiftManagement.KitchenShift;

public interface JobEventReceiver {
    void updateJobAssigned(Job job, KitchenShift shift);
}

